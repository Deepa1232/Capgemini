#class Mat
#@@value = 100
#end

#class Ad < Mat
#@@valu = 20
#end

#class Su < Mat
#@@value = 10
#end

#class Mul < Mat
#@@value = 1
#end

#puts Mat.class_eval("@@value") #class_eval -The block you pass to class_eval is evaluated in the context of that class.
#puts Ad.class_eval("@@value")



class Array

def initialize(astud,aid)
@student = astud
@identity = aid
end

def method1
puts"student name and id is"
puts(@student,@identity)
end
end

Array.new("deepa",1).method1
